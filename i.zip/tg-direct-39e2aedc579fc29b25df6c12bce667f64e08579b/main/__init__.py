# This file is a part of TG-Direct-Link-Generator


import time
from .vars import Var
from main.bot.clients import StreamBot

__version__ = 2.2
StartTime = time.time()
